
public class OddExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=39;
		if(x%2==0)
			System.out.println("Even No");
		else
			System.out.println("Odd Number");

	}
}
