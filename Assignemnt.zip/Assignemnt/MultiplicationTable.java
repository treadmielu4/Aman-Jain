package Assignemnt;
import java.util.*;
public class MultiplicationTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number");
		int n=sc.nextInt();
		System.out.println("Using For loop");
		for(int i=1;i<=10;i++) {
			System.out.println(i+" X "+n+" = "+(n*i));
		}
		
		System.out.println("Using While loop");
		int i=1;
		while(i<=10) {
			System.out.println(i+" X "+n+" = "+(n*i));
			i++;
		}

		System.out.println("Using Do-While loop");
		int j=1;
		do {
			System.out.println(j+" X "+n+" = "+(n*j));
			j++;
		}
		while(j<=10);
	}

}
