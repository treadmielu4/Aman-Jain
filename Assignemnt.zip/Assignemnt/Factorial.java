package Assignemnt;

import java.util.Scanner;

public class Factorial {

	// recursion function to find factorial
	public static int recFactorial(int n) {
		if (n == 0) {
			return 1;
		} else {

			return n * recFactorial(n - 1);
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();

		System.out.println("factorial using recursion for num is :" + recFactorial(num));

	}

}
