package Assignemnt;

import java.util.Scanner;

public class Fibonacci {

	public static int[] fibo(int num) {
		int a = 0, b = 1;
		int arr[] = new int[num];
		arr[0] = 0;
		arr[1] = 1;
		for (int i = 2; i < num; i++) {
			int c = a + b;
			arr[i] = c;
			a = b;
			b = c;

		}
		return arr;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number");
		int num = sc.nextInt();
		int fib[] = fibo(num);
		for (int i = 0; i < num; i++) {
			System.out.print(fib[i] + " ");
		}
		sc.close();

	}

}
