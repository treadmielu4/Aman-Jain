package Assignemnt;
import java.util.Scanner;
public class SumOfDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter number");
		int num=sc.nextInt(),sum=0;;
		while(num>0) {
			int rem=num%10;
			sum+=rem;
			num/=10;
		}
		System.out.println(sum);

	}

}
