package Assignemnt;

import java.util.Scanner;

public class Prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number");
		int num = sc.nextInt(), flag = 0;

		for (int i = 2; i < num / 2; i++) {
			if (num % i == 0) {
				flag = 1;
				break;
			}

		}
		if (flag == 1) {
			System.out.println("Not Prime");
		} else
			System.out.println("prime");

	}

}
