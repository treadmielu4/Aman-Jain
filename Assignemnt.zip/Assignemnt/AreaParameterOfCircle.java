package Assignemnt;

import java.util.*;

public class AreaParameterOfCircle {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int rad = sc.nextInt();
		System.out.println("Area is " + (Math.PI * rad * rad) + "parameter is : " + (2 * Math.PI * rad));
		sc.close();

	}

}
